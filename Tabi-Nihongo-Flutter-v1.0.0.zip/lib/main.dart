import 'package:flutter/material.dart';

void main() => runApp(const TabiNihongoApp());

const _red = Color(0xFFD62929);
const _navy = Color(0xFF16243A);
const _cream = Color(0xFFFFFBF5);
const _green = Color(0xFF55A85C);

class TabiNihongoApp extends StatelessWidget {
  const TabiNihongoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tabi Nihongo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: _red,
          primary: _red,
          surface: _cream,
        ),
        scaffoldBackgroundColor: _cream,
        fontFamilyFallback: const ['Noto Sans Thai', 'Noto Sans JP'],
        appBarTheme: const AppBarTheme(
          backgroundColor: _cream,
          foregroundColor: _navy,
          centerTitle: true,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFECE5DC)),
          ),
        ),
      ),
      home: const AppShell(),
    );
  }
}

class Phrase {
  const Phrase(this.thai, this.jp, this.romaji, this.pronunciation);
  final String thai;
  final String jp;
  final String romaji;
  final String pronunciation;
}

const phrases = <Phrase>[
  Phrase('ขอโทษครับ/ค่ะ', 'すみません', 'Sumimasen', 'ซุมิมาเซ็น'),
  Phrase('ห้องน้ำอยู่ที่ไหน?', 'トイレはどこですか？', 'Toire wa doko desu ka?', 'โทอิเระ วะ โดโกะ เดสก๊ะ'),
  Phrase('เมนูแนะนำคืออะไรครับ/คะ', 'おすすめは何ですか？', 'Osusume wa nan desu ka?', 'โอซุสุเมะ วะ นัน เดสก๊ะ'),
  Phrase('คิดเงินด้วยครับ/ค่ะ', 'お会計をお願いします', 'Okaikei o onegaishimasu', 'โอไคเค โอะ โอเนไกชิมัส'),
  Phrase('ที่จอดรถอยู่ที่ไหน?', '駐車場はどこですか？', 'Chūshajō wa doko desu ka?', 'ชูชะโจ วะ โดโกะ เดสก๊ะ'),
  Phrase('พักสองคืนครับ/ค่ะ', '二泊です', 'Nihaku desu', 'นิฮะคุ เดส'),
  Phrase('ผู้ใหญ่สองคน เด็กสองคน', '大人二人、子供二人です', 'Otona futari, kodomo futari desu', 'โอโตนะ ฟุตาริ โคโดโมะ ฟุตาริ เดส'),
  Phrase('ช่วยด้วยครับ/ค่ะ', '助けてください', 'Tasukete kudasai', 'ทะสุเคะเตะ คุดะไซ'),
];

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final favorites = <int>{1, 2};

  void open(int next) => setState(() => index = next);

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpen: open),
      LearnPage(onOpen: open),
      const ListeningPage(),
      const SpeakingPage(),
      FavoritesPage(
        favorites: favorites,
        onToggle: (i) => setState(() => favorites.contains(i) ? favorites.remove(i) : favorites.add(i)),
      ),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        height: 70,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFFFDEDA),
        onDestinationSelected: open,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'หน้าแรก'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'เรียน'),
          NavigationDestination(icon: Icon(Icons.headphones_outlined), selectedIcon: Icon(Icons.headphones), label: 'ฝึกฟัง'),
          NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'ฝึกพูด'),
          NavigationDestination(icon: Icon(Icons.star_outline), selectedIcon: Icon(Icons.star), label: 'โปรด'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.onOpen});
  final ValueChanged<int> onOpen;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Expanded(
              child: Text('พร้อมเที่ยวญี่ปุ่น\nหรือยัง?', style: TextStyle(fontSize: 30, height: 1.15, fontWeight: FontWeight.w900, color: _navy)),
            ),
            Container(
              width: 76,
              height: 76,
              decoration: const BoxDecoration(color: Color(0xFFFFE6DF), shape: BoxShape.circle),
              alignment: Alignment.center,
              child: const Text('日本', style: TextStyle(fontSize: 26, color: _red, fontWeight: FontWeight.w900)),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              const SizedBox.square(
                dimension: 70,
                child: Stack(alignment: Alignment.center, children: [
                  CircularProgressIndicator(value: .35, strokeWidth: 8, color: _green, backgroundColor: Color(0xFFE8EEE7)),
                  Text('35%', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                ]),
              ),
              const SizedBox(width: 16),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('ความก้าวหน้าประจำวัน', style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 5),
                Text('เรียนไปแล้ว 7 / 20 บทเรียน', style: TextStyle(color: Colors.black54)),
              ])),
              IconButton(onPressed: () {}, icon: const Icon(Icons.chevron_right)),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          readOnly: true,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuickPhrasePage())),
          decoration: InputDecoration(
            hintText: 'ค้นหาประโยคหรือหมวดหมู่',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: const Icon(Icons.tune),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 22),
        const Text('หมวดหมู่', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: _navy)),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: .95,
          children: const [
            CategoryTile(Icons.flight, 'สนามบิน', Color(0xFF368CCB)),
            CategoryTile(Icons.ramen_dining, 'ร้านอาหาร', Color(0xFFE8583D)),
            CategoryTile(Icons.apartment, 'โรงแรม', Color(0xFF58A367)),
            CategoryTile(Icons.train, 'การเดินทาง', Color(0xFF325C9B)),
            CategoryTile(Icons.shopping_bag, 'ช้อปปิ้ง', Color(0xFF8057B5)),
            CategoryTile(Icons.medical_services, 'ฉุกเฉิน', Color(0xFFD73A32)),
          ],
        ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NumberCoursePage())),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: _red, borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Color(0x33D62929), blurRadius: 16, offset: Offset(0, 7))]),
            child: const Row(children: [
              CircleAvatar(radius: 28, backgroundColor: Colors.white, child: Text('¥123', style: TextStyle(color: _red, fontWeight: FontWeight.w900, fontSize: 17))),
              SizedBox(width: 15),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('ตัวเลข・ราคา', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                Text('หน่วย สิบ ร้อย พัน หมื่น', style: TextStyle(color: Color(0xFFFFDAD5))),
              ])),
              Icon(Icons.chevron_right, color: Colors.white),
            ]),
          ),
        ),
        const SizedBox(height: 22),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('ประโยคด่วนระหว่างเที่ยว', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuickPhrasePage())), child: const Text('ดูทั้งหมด')),
        ]),
        Card(child: ListTile(
          contentPadding: const EdgeInsets.all(16),
          leading: const CircleAvatar(backgroundColor: Color(0xFFFFE5E1), child: Icon(Icons.volume_up, color: _red)),
          title: Text(phrases[1].thai, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${phrases[1].jp}\n${phrases[1].romaji}'),
          isThreeLine: true,
          trailing: const Icon(Icons.open_in_new),
        )),
      ],
    );
  }
}

class CategoryTile extends StatelessWidget {
  const CategoryTile(this.icon, this.label, this.color, {super.key});
  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonPage(title: label))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 36, color: color),
        const SizedBox(height: 10),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
      ]),
    ),
  );
}

class LearnPage extends StatelessWidget {
  const LearnPage({super.key, required this.onOpen});
  final ValueChanged<int> onOpen;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const PageHeading('บทเรียนของฉัน', 'เรียนทีละนิด ใช้ได้จริงทุกทริป'),
      const SizedBox(height: 18),
      _CourseCard(title: 'ตัวเลข・ราคา', subtitle: '5 บทเรียน • สำเร็จ 3 บท', progress: .6, icon: Icons.currency_yen, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NumberCoursePage()))),
      const SizedBox(height: 12),
      _CourseCard(title: 'ร้านอาหาร', subtitle: '20 ประโยค • สำเร็จ 12 ประโยค', progress: .6, icon: Icons.ramen_dining, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LessonPage(title: 'ร้านอาหาร')))),
      const SizedBox(height: 12),
      _CourseCard(title: 'โรงแรมและที่พัก', subtitle: '18 ประโยค • สำเร็จ 5 ประโยค', progress: .28, icon: Icons.hotel, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LessonPage(title: 'โรงแรม')))),
      const SizedBox(height: 12),
      _CourseCard(title: 'การเดินทาง', subtitle: '24 ประโยค • ยังไม่ได้เริ่ม', progress: 0, icon: Icons.train, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LessonPage(title: 'การเดินทาง')))),
    ],
  );
}

class _CourseCard extends StatelessWidget {
  const _CourseCard({required this.title, required this.subtitle, required this.progress, required this.icon, required this.onTap});
  final String title, subtitle;
  final double progress;
  final IconData icon;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(child: InkWell(
    borderRadius: BorderRadius.circular(20),
    onTap: onTap,
    child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
      CircleAvatar(radius: 27, backgroundColor: const Color(0xFFFFE7E2), child: Icon(icon, color: _red, size: 29)),
      const SizedBox(width: 15),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 10),
        LinearProgressIndicator(value: progress, minHeight: 7, borderRadius: BorderRadius.circular(10), color: _red, backgroundColor: const Color(0xFFF2EAE7)),
      ])),
      const SizedBox(width: 8),
      const Icon(Icons.chevron_right),
    ])),
  ));
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.title});
  final String title;
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  int current = 0;
  @override
  Widget build(BuildContext context) {
    final p = phrases[current % phrases.length];
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, style: const TextStyle(color: _red, fontWeight: FontWeight.w900))),
      body: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        Row(children: [Expanded(child: LinearProgressIndicator(value: (current + 1) / phrases.length, minHeight: 8, borderRadius: BorderRadius.circular(8))), const SizedBox(width: 12), Text('${current + 1}/${phrases.length}')]),
        const SizedBox(height: 24),
        Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(p.jp, textAlign: TextAlign.center, style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: _navy)),
          const SizedBox(height: 18),
          Text(p.romaji, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, color: _red)),
          const SizedBox(height: 8),
          Text(p.pronunciation, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, color: Colors.black54)),
          const Divider(height: 40),
          const Text('ความหมาย', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 6),
          Text(p.thai, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 28),
          FilledButton.tonalIcon(onPressed: () => _showAudio(context, p.jp), icon: const Icon(Icons.volume_up), label: const Text('ฟังเสียง')),
          TextButton.icon(onPressed: () => _showAudio(context, 'เสียงช้า: ${p.jp}'), icon: const Icon(Icons.slow_motion_video), label: const Text('สปีดช้า')),
        ])))),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: current == 0 ? null : () => setState(() => current--), icon: const Icon(Icons.chevron_left), label: const Text('ก่อนหน้า'))),
          const SizedBox(width: 12),
          Expanded(child: FilledButton.icon(onPressed: () => setState(() => current = (current + 1) % phrases.length), iconAlignment: IconAlignment.end, icon: const Icon(Icons.chevron_right), label: const Text('ถัดไป'))),
        ]),
      ])),
    );
  }
}

class NumberCoursePage extends StatelessWidget {
  const NumberCoursePage({super.key});
  static const lessons = [
    ('หน่วย 1–9', '一・二・三・四・五', 'พื้นฐานการอ่านตัวเลข'),
    ('หลักสิบ 10–99', '十・二十・九十九', 'ประกอบเลขสิบกับหลักหน่วย'),
    ('หลักร้อย 100–999', '百・三百・六百・八百', 'ฝึกเสียงพิเศษ 300, 600, 800'),
    ('หลักพัน 1,000–9,999', '千・三千・八千', 'ฝึกเสียงพิเศษ 3,000 และ 8,000'),
    ('หลักหมื่น 10,000–99,999', '一万・二万・九万', 'เข้าใจหน่วย 万 ของภาษาญี่ปุ่น'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ตัวเลข・ราคา', style: TextStyle(color: _red, fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('ความก้าวหน้ารวม', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const LinearProgressIndicator(value: .6, minHeight: 9, borderRadius: BorderRadius.all(Radius.circular(8))),
      const SizedBox(height: 20),
      ...List.generate(lessons.length, (i) {
        final item = lessons[i];
        return Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          leading: CircleAvatar(backgroundColor: i < 3 ? _red : const Color(0xFFE9E3DC), foregroundColor: i < 3 ? Colors.white : _navy, child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w900))),
          title: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text('${item.$2}\n${item.$3}'),
          isThreeLine: true,
          trailing: const Icon(Icons.volume_up_outlined),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NumberLessonPage(level: i))),
        )));
      }),
      const SizedBox(height: 4),
      FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceValuePage())), icon: const Icon(Icons.grid_view), label: const Text('ฝึกแยกหลักตัวเลข')),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckoutPage())), icon: const Icon(Icons.shopping_basket), label: const Text('จำลองร้านสะดวกซื้อ')),
    ]),
  );
}

class NumberLessonPage extends StatelessWidget {
  const NumberLessonPage({super.key, required this.level});
  final int level;
  static const rows = [
    [('1', '一', 'いち', 'อิจิ'), ('2', '二', 'に', 'นิ'), ('3', '三', 'さん', 'ซัง'), ('4', '四', 'よん', 'ยง'), ('5', '五', 'ご', 'โกะ'), ('6', '六', 'ろく', 'โระคุ'), ('7', '七', 'なな', 'นะนะ'), ('8', '八', 'はち', 'ฮะจิ'), ('9', '九', 'きゅう', 'คิว')],
    [('10', '十', 'じゅう', 'จู'), ('20', '二十', 'にじゅう', 'นิจู'), ('35', '三十五', 'さんじゅうご', 'ซันจูโกะ'), ('99', '九十九', 'きゅうじゅうきゅう', 'คิวจูคิว')],
    [('100', '百', 'ひゃく', 'เฮียคุ'), ('300', '三百', 'さんびゃく', 'ซัมเบียคุ'), ('600', '六百', 'ろっぴゃく', 'รปเปียคุ'), ('800', '八百', 'はっぴゃく', 'ฮัปเปียคุ')],
    [('1,000', '千', 'せん', 'เซ็น'), ('3,000', '三千', 'さんぜん', 'ซันเซ็น'), ('8,000', '八千', 'はっせん', 'ฮัสเซ็น'), ('9,500', '九千五百', 'きゅうせんごひゃく', 'คิวเซ็นโกะเฮียคุ')],
    [('10,000', '一万', 'いちまん', 'อิจิมัง'), ('20,000', '二万', 'にまん', 'นิมัง'), ('35,000', '三万五千', 'さんまんごせん', 'ซัมมังโกะเซ็น'), ('99,999', '九万九千九百九十九', 'きゅうまんきゅうせんきゅうひゃくきゅうじゅうきゅう', 'คิวมัง คิวเซ็น คิวเฮียคุ คิวจูคิว')],
  ];

  @override
  Widget build(BuildContext context) {
    final items = rows[level];
    return Scaffold(
      appBar: AppBar(title: Text(NumberCoursePage.lessons[level].$1, style: const TextStyle(color: _red, fontWeight: FontWeight.w900))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(NumberCoursePage.lessons[level].$3, style: const TextStyle(fontSize: 17, color: Colors.black54)),
        const SizedBox(height: 16),
        ...items.map((n) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(child: ListTile(
          contentPadding: const EdgeInsets.all(16),
          leading: CircleAvatar(radius: 27, backgroundColor: const Color(0xFFFFE5E1), child: Text(n.$1, style: const TextStyle(fontSize: 13, color: _red, fontWeight: FontWeight.w900))),
          title: Text('${n.$2}  ${n.$3}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          subtitle: Text(n.$4, style: const TextStyle(fontSize: 16)),
          trailing: IconButton(onPressed: () => _showAudio(context, n.$3), icon: const Icon(Icons.volume_up, color: _red)),
        )))),
        FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ListeningPage(standalone: true))), child: const Text('เริ่มแบบฝึกฟัง')),
      ]),
    );
  }
}

class PlaceValuePage extends StatefulWidget {
  const PlaceValuePage({super.key});
  @override
  State<PlaceValuePage> createState() => _PlaceValuePageState();
}

class _PlaceValuePageState extends State<PlaceValuePage> {
  int example = 0;
  static const data = [
    ('23,850', '2万 + 3千 + 8百 + 5十', '二万三千八百五十', 'にまん さんぜん はっぴゃく ごじゅう', 'นิมัง ซันเซ็น ฮัปเปียคุ โกะจู'),
    ('6,480', '6千 + 4百 + 8十', '六千四百八十', 'ろくせん よんひゃく はちじゅう', 'โระคุเซ็น ยงเฮียคุ ฮะจิจู'),
    ('12,300', '1万 + 2千 + 3百', '一万二千三百', 'いちまん にせん さんびゃく', 'อิจิมัง นิเซ็น ซัมเบียคุ'),
  ];
  @override
  Widget build(BuildContext context) {
    final n = data[example];
    return Scaffold(
      appBar: AppBar(title: const Text('แยกหลักตัวเลข', style: TextStyle(color: _red, fontWeight: FontWeight.w900))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Center(child: Text(n.$1, style: const TextStyle(fontSize: 48, color: _navy, fontWeight: FontWeight.w900))),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Text(n.$2, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, color: _red, fontWeight: FontWeight.w900)),
          const Divider(height: 34),
          Text(n.$3, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8), Text(n.$4, textAlign: TextAlign.center),
          const SizedBox(height: 6), Text(n.$5, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, fontSize: 16)),
        ]))),
        const SizedBox(height: 18),
        const Row(children: [
          Expanded(child: PlaceChip('万', '10,000', Color(0xFFD84B40))), SizedBox(width: 6),
          Expanded(child: PlaceChip('千', '1,000', Color(0xFFE88A24))), SizedBox(width: 6),
          Expanded(child: PlaceChip('百', '100', Color(0xFF4D9A59))), SizedBox(width: 6),
          Expanded(child: PlaceChip('十', '10', Color(0xFF397EC0))), SizedBox(width: 6),
          Expanded(child: PlaceChip('一', '1', Color(0xFF7654A5))),
        ]),
        const SizedBox(height: 20),
        Center(child: FloatingActionButton.large(onPressed: () => _showAudio(context, n.$4), child: const Icon(Icons.volume_up, size: 36))),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: () => setState(() => example = (example + 1) % data.length), iconAlignment: IconAlignment.end, icon: const Icon(Icons.chevron_right), label: const Text('ตัวอย่างถัดไป')),
      ]),
    );
  }
}

class PlaceChip extends StatelessWidget {
  const PlaceChip(this.jp, this.number, this.color, {super.key});
  final String jp, number;
  final Color color;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () => _showAudio(context, '$jp เท่ากับ $number'),
    child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text(jp, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)), Text(number, style: const TextStyle(color: Colors.white, fontSize: 11))])),
  );
}

class ListeningPage extends StatefulWidget {
  const ListeningPage({super.key, this.standalone = false});
  final bool standalone;
  @override
  State<ListeningPage> createState() => _ListeningPageState();
}

class _ListeningPageState extends State<ListeningPage> {
  final questions = const [
    (3850, 'さんぜん はっぴゃく ごじゅうえん', [3580, 3850, 8350, 3805]),
    (1280, 'せん にひゃく はちじゅうえん', [1820, 1280, 1208, 2180]),
    (12300, 'いちまん にせん さんびゃくえん', [13200, 12300, 12030, 2300]),
  ];
  int current = 0;
  int? selected;

  @override
  Widget build(BuildContext context) {
    final q = questions[current];
    final content = ListView(padding: const EdgeInsets.all(18), children: [
      const PageHeading('ฟังราคา', 'ฟังภาษาญี่ปุ่นแล้วเลือกตัวเลขที่ถูกต้อง'),
      const SizedBox(height: 14),
      Row(children: [Expanded(child: LinearProgressIndicator(value: (current + 1) / 10, minHeight: 8, borderRadius: BorderRadius.circular(8))), const SizedBox(width: 12), Text('${current + 1}/10')]),
      const SizedBox(height: 30),
      Center(child: FloatingActionButton.large(onPressed: () => _showAudio(context, q.$2), child: const Icon(Icons.volume_up, size: 38))),
      const SizedBox(height: 14),
      const Center(child: Text('แตะเพื่อฟังอีกครั้ง', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 28),
      GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.35,
        children: q.$3.map((answer) {
          final isSelected = selected == answer;
          final correct = selected != null && answer == q.$1;
          return InkWell(onTap: () => setState(() => selected = answer), borderRadius: BorderRadius.circular(18), child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(color: correct ? const Color(0xFFE3F4E4) : isSelected ? const Color(0xFFFFE3DF) : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: correct ? _green : isSelected ? _red : const Color(0xFFE8E0D8), width: 2)),
            child: Text('¥${_comma(answer)}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: _navy)),
          ));
        }).toList(),
      ),
      if (selected != null) ...[
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: selected == q.$1 ? const Color(0xFFE4F4E5) : const Color(0xFFFFE5E1), borderRadius: BorderRadius.circular(16)), child: Text(selected == q.$1 ? 'ถูกต้อง! ${q.$2}' : 'ลองอีกครั้ง แล้วแยกเสียงหลักพัน–ร้อย–สิบ', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800, color: selected == q.$1 ? const Color(0xFF287A31) : _red))),
        const SizedBox(height: 12),
        FilledButton(onPressed: () => setState(() {current = (current + 1) % questions.length; selected = null;}), child: const Text('ข้อต่อไป')),
      ],
    ]);
    if (!widget.standalone) return content;
    return Scaffold(appBar: AppBar(title: const Text('แบบฝึกฟังราคา')), body: content);
  }
}

class SpeakingPage extends StatefulWidget {
  const SpeakingPage({super.key});
  @override
  State<SpeakingPage> createState() => _SpeakingPageState();
}

class _SpeakingPageState extends State<SpeakingPage> {
  bool recorded = false;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const PageHeading('ฝึกพูด', 'จำลองบทสนทนาในร้านอาหาร'),
    const SizedBox(height: 20),
    Container(height: 170, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFF7C789), Color(0xFFF4E2C9)]), borderRadius: BorderRadius.circular(24)), child: const Center(child: CircleAvatar(radius: 50, backgroundColor: Colors.white, child: Icon(Icons.person, size: 60, color: _red)))),
    const SizedBox(height: 14),
    const SpeechBubble('いらっしゃいませ！\nご注文はお決まりですか？', false),
    const SizedBox(height: 10),
    const SpeechBubble('おすすめは何ですか？', true),
    const SizedBox(height: 22),
    if (recorded) Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
      const Text('คะแนนการออกเสียง', style: TextStyle(fontWeight: FontWeight.w700)),
      const Text('86%', style: TextStyle(fontSize: 42, color: _green, fontWeight: FontWeight.w900)),
      _score('ความชัดเจน', .88), const SizedBox(height: 8), _score('จังหวะ', .84),
    ]))) else const Center(child: Text('おすすめは何ですか？\nโอซุสุเมะ วะ นัน เดสก๊ะ', textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
    const SizedBox(height: 22),
    Center(child: FloatingActionButton.large(onPressed: () => setState(() => recorded = !recorded), child: Icon(recorded ? Icons.refresh : Icons.mic, size: 38))),
    const SizedBox(height: 10),
    Center(child: Text(recorded ? 'แตะเพื่อลองใหม่' : 'แตะเพื่อพูด', style: const TextStyle(color: Colors.black54))),
  ]);
}

Widget _score(String label, double value) => Row(children: [SizedBox(width: 80, child: Text(label)), Expanded(child: LinearProgressIndicator(value: value, minHeight: 8, color: _green, backgroundColor: const Color(0xFFEAE7E1))), const SizedBox(width: 8), Text('${(value * 100).round()}%')]);

class SpeechBubble extends StatelessWidget {
  const SpeechBubble(this.text, this.mine, {super.key});
  final String text;
  final bool mine;
  @override
  Widget build(BuildContext context) => Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13), decoration: BoxDecoration(color: mine ? const Color(0xFFFFDEDA) : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFECE5DC))), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700))));
}

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  int paid = 0;
  static const total = 3850;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ร้านสะดวกซื้อ', style: TextStyle(color: _red, fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(height: 170, decoration: BoxDecoration(color: const Color(0xFFE8F4E8), borderRadius: BorderRadius.circular(22)), child: const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [Icon(Icons.person, size: 80, color: _green), Icon(Icons.shopping_basket, size: 80, color: _red)])),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const Text('合計', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const Text('¥3,850', style: TextStyle(fontSize: 38, color: _red, fontWeight: FontWeight.w900)),
        FilledButton.tonalIcon(onPressed: () => _showAudio(context, 'さんぜん はっぴゃく ごじゅうえんです'), icon: const Icon(Icons.volume_up), label: const Text('ฟังพนักงานบอกราคา')),
      ]))),
      const SizedBox(height: 18),
      const Text('เลือกเงินที่คุณใช้จ่าย', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: [10000, 5000, 2000, 1000, 500, 100, 50, 10].map((v) => ActionChip(avatar: Icon(v >= 1000 ? Icons.payments : Icons.monetization_on, size: 18), label: Text('¥${_comma(v)}'), onPressed: () => setState(() => paid += v))).toList()),
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('จำนวนที่จ่าย'), Text('¥${_comma(paid)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20))]),
        const Divider(),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('เงินทอน'), Text(paid >= total ? '¥${_comma(paid - total)}' : 'ยังขาด ¥${_comma(total - paid)}', style: TextStyle(fontWeight: FontWeight.w900, color: paid >= total ? _green : _red))]),
      ]))),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: OutlinedButton(onPressed: () => setState(() => paid = 0), child: const Text('เริ่มใหม่'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: paid >= total ? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ถูกต้อง รับเงินทอน ¥${_comma(paid - total)}'))) : null, child: const Text('ยืนยันคำตอบ')))]),
    ]),
  );
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key, required this.favorites, required this.onToggle});
  final Set<int> favorites;
  final ValueChanged<int> onToggle;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const PageHeading('รายการโปรด', 'ประโยคที่บันทึกไว้ใช้ระหว่างเที่ยว'),
    const SizedBox(height: 16),
    if (favorites.isEmpty) const Padding(padding: EdgeInsets.only(top: 80), child: Column(children: [Icon(Icons.star_outline, size: 70, color: Colors.black26), SizedBox(height: 12), Text('ยังไม่มีรายการโปรด')])),
    ...favorites.map((i) => PhraseCard(index: i, favorite: true, onFavorite: () => onToggle(i))),
  ]);
}

class QuickPhrasePage extends StatefulWidget {
  const QuickPhrasePage({super.key});
  @override
  State<QuickPhrasePage> createState() => _QuickPhrasePageState();
}

class _QuickPhrasePageState extends State<QuickPhrasePage> {
  String query = '';
  final favorites = <int>{1, 2};
  @override
  Widget build(BuildContext context) {
    final filtered = List.generate(phrases.length, (i) => i).where((i) { final p = phrases[i]; return p.thai.contains(query) || p.jp.contains(query) || p.romaji.toLowerCase().contains(query.toLowerCase()); }).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('ใช้ด่วนระหว่างเที่ยว', style: TextStyle(color: _red, fontWeight: FontWeight.w900))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFE4F3E3), borderRadius: BorderRadius.circular(30)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.offline_bolt, color: _green, size: 18), SizedBox(width: 6), Text('ใช้งานออฟไลน์ได้', style: TextStyle(color: Color(0xFF32753A), fontWeight: FontWeight.w700))])),
        const SizedBox(height: 14),
        TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: 'ค้นหาประโยคด่วน', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
        const SizedBox(height: 14),
        ...filtered.map((i) => PhraseCard(index: i, favorite: favorites.contains(i), onFavorite: () => setState(() => favorites.contains(i) ? favorites.remove(i) : favorites.add(i)))),
      ]),
    );
  }
}

class PhraseCard extends StatelessWidget {
  const PhraseCard({super.key, required this.index, required this.favorite, required this.onFavorite});
  final int index;
  final bool favorite;
  final VoidCallback onFavorite;
  @override
  Widget build(BuildContext context) {
    final p = phrases[index];
    return Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(padding: const EdgeInsets.fromLTRB(24, 10, 24, 34), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(p.thai, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 14), Text(p.jp, textAlign: TextAlign.center, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(p.romaji, style: const TextStyle(color: _red, fontSize: 18)), Text(p.pronunciation), const SizedBox(height: 22), FilledButton.icon(onPressed: () => _showAudio(context, p.jp), icon: const Icon(Icons.volume_up), label: const Text('เปิดเสียงและแสดงให้คนญี่ปุ่นดู'))]))),
      child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.thai, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(p.jp, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text(p.romaji, style: const TextStyle(color: _red))])),
        Column(children: [IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.star : Icons.star_outline, color: _red)), IconButton(onPressed: () => _showAudio(context, p.jp), icon: const Icon(Icons.volume_up))]),
      ])),
    )));
  }
}

class PageHeading extends StatelessWidget {
  const PageHeading(this.title, this.subtitle, {super.key});
  final String title, subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 28, color: _navy, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 16))]);
}

void _showAudio(BuildContext context, String text) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Row(children: [const Icon(Icons.volume_up, color: Colors.white), const SizedBox(width: 10), Expanded(child: Text('กำลังเล่นเสียง: $text'))]), duration: const Duration(seconds: 2)));
}

String _comma(int value) {
  final chars = value.toString().split('').reversed.toList();
  final out = <String>[];
  for (var i = 0; i < chars.length; i++) {
    if (i > 0 && i % 3 == 0) out.add(',');
    out.add(chars[i]);
  }
  return out.reversed.join();
}
