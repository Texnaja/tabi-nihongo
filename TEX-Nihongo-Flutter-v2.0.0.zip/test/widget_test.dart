import 'package:flutter_test/flutter_test.dart';
import 'package:tabi_nihongo/main.dart';

void main() {
  testWidgets('shows the app home screen', (tester) async {
    await tester.pumpWidget(const TabiNihongoApp());
    expect(find.textContaining('พร้อมเที่ยวญี่ปุ่น'), findsOneWidget);
    expect(find.text('ตัวเลข・ราคา'), findsWidgets);
  });
}
