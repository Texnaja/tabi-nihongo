import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tabi_nihongo/main.dart';

void main() {
  testWidgets('shows the TEX Nihongo home screen', (tester) async {
    // Use a phone-like portrait canvas. The default widget-test canvas is
    // short and can report layout overflows for the full application shell.
    await tester.binding.setSurfaceSize(const Size(1080, 2400));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(const TabiNihongoApp());
    await tester.pump();

    expect(find.text('TEX Nihongo'), findsOneWidget);
    expect(find.text('หน้าแรก'), findsOneWidget);
  });
}
