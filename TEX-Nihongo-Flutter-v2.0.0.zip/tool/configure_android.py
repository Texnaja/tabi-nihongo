from pathlib import Path


manifest_path = Path("android/app/src/main/AndroidManifest.xml")
manifest = manifest_path.read_text(encoding="utf-8")

permissions = """    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.BLUETOOTH" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
"""

queries = """    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService" />
        </intent>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE" />
        </intent>
    </queries>
"""

if "android.permission.RECORD_AUDIO" not in manifest:
    manifest = manifest.replace("    <application", permissions + queries + "    <application", 1)

manifest = manifest.replace('android:label="tabi_nihongo"', 'android:label="TEX Nihongo"')
manifest = manifest.replace('android:label="tex_nihongo"', 'android:label="TEX Nihongo"')
manifest_path.write_text(manifest, encoding="utf-8")

print("Configured Android permissions and TEX Nihongo label")
